package model;

/**
 * The Class Entity.
 *
 * @author Jean-Aymeric Diet
 */
abstract class Entity {

}
